import { Flex, Grid, useEditable } from "@chakra-ui/react";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { getRooms } from "../api";
import Room from "../components/Room";
import RoomSkeleton from "../components/RoomSkeleton";
import { IRoomList } from "../types";
import { Button } from "@chakra-ui/react";
import React, { useState } from 'react';
import { SiGooglemaps } from "react-icons/si";

export default function Home() {
  const [showMap, setShowMap] = useState(false); // 지도 표시 상태

  const toggleMap = () => setShowMap(!showMap);

  const { isLoading, data } = useQuery<IRoomList[]>(["rooms"], getRooms);

  return (
        <>
      <div style={{ 
        position: 'fixed', 
        bottom: '40px', 
        left: '50%', 
        transform: 'translateX(-50%)', 
        zIndex: 10 
      }}>
        <Button leftIcon={<SiGooglemaps style={{ color: '#3EB489' }}/>} 
            colorScheme='gray' 
            onClick={toggleMap} 
            size='lg'>
            {showMap ? "지도 숨기기" : "지도 보기"}
        </Button>
      </div>
      {
        showMap 
      }

      <Grid
        mt={10}
        px={{
          base: 10,
          lg: 40,
        }}
        columnGap={4}
        rowGap={8}
        templateColumns={{
          sm: "1fr",
          md: "1fr 1fr",
          lg: "repeat(3, 1fr)",
          xl: "repeat(4, 1fr)",
          "2xl": "repeat(5, 1fr)",
        }}
      >
        {isLoading ? (
          <>
            <RoomSkeleton />
            {/* 여기에 추가적인 RoomSkeleton 컴포넌트 */}
          </>
        ) : null}
        {data?.map((room) => (  /*여기 map은 지도의 map 아님 */
          <Room
            key={room.pk}
            pk={room.pk}
            isOwner={room.is_owner}
            imageUrl={room.photos[0].file}
            name={room.name}
            rating={room.rating}
            city={room.city}
            country={room.country}
            price={room.price}
          />
        ))}
      </Grid>
    </>
  );
}
